HFValid Pat001 reconstruction model - step 14

Coordinates: millimeters, original undeformed geometry, scale 1:1.
All STLs share one translation. Import them together as parts of one object to inspect assembly.
For printing, arrange parts on the plate and apply the SAME uniform scale to every part.
No fit clearance is applied; printer tolerances and assembly access must be checked.
Inspect thin features and small parts in the slicer; choose orientation and supports.
The original full femur is approximately 397 mm tall; 50% is approximately 198.5 mm.

Print repair adds 20.340 mm3 to the simulated missing region.
Those elements are removed from the matching remaining pieces. No vertex is moved or smoothed.
Remaining fragments below 5 mm3 are absorbed into the insert, and counted in the repair volume.
Use this matching set; the separate intact STL uses a different surface resolution.
This is a physical model of simulated element erosion, not an implant or actual missing tissue.

Aldieri, La Mattina, Szyszko, Baruffaldi, Viceconti (2025). HFValid collection. University of Bologna. DOI:10.6092/unibo/amsacta/8431
https://amsacta.unibo.it/id/eprint/8431/
License: CC BY 4.0
